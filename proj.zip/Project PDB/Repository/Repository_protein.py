import csv
import os
from Repository.RepositoryError import RepositoryError
from Domeniu.Protein import Protein

class RepositoryProtein:
    def __init__(self, filename="proteins.csv"):
        self._proteins = {}
        self.filename = filename
        self.load_from_file()

    def add_protein(self, protein):
        if protein.get_identifier() in self._proteins:
            raise RepositoryError("Protein exists!")
        self._proteins[protein.get_identifier()] = protein
        self.save_to_file()

    def remove_protein_(self, identifier_protein):
        if identifier_protein not in self._proteins:
            raise RepositoryError("Protein does not exist!")
        del self._proteins[identifier_protein]
        self.save_to_file()

    def update_protein_(self, identifier_protein, new_protein):
        if identifier_protein not in self._proteins:
            raise RepositoryError("Protein does not exist!")
        self._proteins[identifier_protein] = new_protein

    def search_protein(self, identifier_protein):
        return self._proteins.get(identifier_protein, None)

    def __len__(self):
        return len(self._proteins)

    def get_all(self):
        return list(self._proteins.values())

    def save_to_file(self):
        with open(self.filename, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["ID", "Molecular Weight", "Atom Count"])
            writer.writerows([[p.get_identifier(), p.get_deposited_atom_count(), p.get_molecular_weight()]
                              for p in self._proteins.values()])

    def load_from_file(self):
        with open(self.filename, "r") as file:
            reader = csv.reader(file)
            next(reader, None)
            self._proteins = {row[0]: Protein(row[0], int(row[1]), float(row[2])) for row in reader if
                              len(row) == 3}

