class RepositoryError(Exception):
    pass

class ValidationError(Exception):
    pass
