
from Errors.Error_Validation import ErrorValidation
from Repository.RepositoryError import RepositoryError


class Console:
    def __init__(self,service):
        self.__service = service
        self.__commands = {
            "add_protein":self.__ui_add_protein,
            "display_proteins":self.__ui_display_proteins,
            "len_protein":self.__ui_len_protein,
            "remove_protein": self.__ui_remove_protein
        }

    def __ui_add_protein(self):
        id_protein = input("Enter protein id:")
        molecular_weight = float(input("Enter molecular weight:"))
        deposited_atom_count = int(input("Enter deposited atom count:"))
        self.__service.fabric_protein(id_protein,deposited_atom_count,molecular_weight)

    def __ui_remove_protein(self):
        identifier_protein = input("Enter the ID of the protein to remove: ")
        try:
            self.__service.remove_protein(identifier_protein)
            print(f"Protein '{identifier_protein}' removed successfully.")
        except RepositoryError as BADID:
            print(f"Error: {BADID}")


    def __ui_display_proteins(self):
        proteins = self.__service.get_all()
        if not proteins:
            print("No stored proteins.")
            return
        print("\nStored Proteins (ID, Molecular Weight, Atom Count)")

        for protein in proteins:
            print(protein)

    def __ui_len_protein(self):
        proteins = self.__service.get_all()
        print(len(proteins))


    def run(self):
        print("\n=== Available Commands ===")
        print("1  Add a protein         (or type: add_protein)")
        print("2  Show stored proteins  (or type: display_proteins)")
        print("3  Show protein count    (or type: len_protein)")
        print("4  Delete protein        (or type: remove_protein")
        print("5  Exit                  (or type: exit)")

        while True:
            command_shortcuts = {
                "1": "add_protein",
                "2": "display_proteins",
                "3": "len_protein",
                "4": "remove_protein",
                "5": "exit"
            }

            command = input("Enter command:")
            command = command.strip().lower()
            if command in command_shortcuts:
                command = command_shortcuts[command]

            if command == "":
                continue
            if command == "exit":
                return
            if command in self.__commands:
                try:
                    self.__commands[command]()
                except ValueError:
                    print("Invalid numerical value!")
                except ErrorValidation as ev:
                    print("Validation error:\n"+str(ev))
                except RepositoryError as re:
                    print("Repository error:\n"+str(re))

            else:
                print("Invalid command!")