import pandas as pd

protein_list = pd.read_csv(r"C:\Users\turia\OneDrive\Documente\Domeniu_Protein.csv")

print(protein_list)