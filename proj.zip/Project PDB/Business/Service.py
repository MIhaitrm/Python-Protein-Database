from Domeniu import Protein
from Domeniu.Protein import Protein
from Protein.Domeniu_Protein import validate_protein
from Validation import *
class ServiceProtein:
    def __init__(self, validate_protein, repository):
        self.__validation_protein = validate_protein
        self.__repository = repository


    def fabric_protein(self, identifier, deposited_atom_count, molecular_weight):
        new_protein = Protein(identifier, deposited_atom_count, molecular_weight)
        self.__validation_protein.validate_protein(new_protein)
        self.__Repository_proteins.add_protein(new_protein)

    def get_all(self):
        return self.__repository.get_all()


    def remove_protein(self, identifier_protein):
        self.__repository.remove_protein_(identifier_protein)
